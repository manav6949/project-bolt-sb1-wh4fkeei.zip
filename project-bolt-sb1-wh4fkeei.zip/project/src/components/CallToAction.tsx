import React, { useRef, useEffect, useState } from 'react';
import { ArrowRight } from 'lucide-react';

const CallToAction: React.FC = () => {
  const ctaRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      {
        threshold: 0.1,
      }
    );
    
    if (ctaRef.current) {
      observer.observe(ctaRef.current);
    }
    
    return () => {
      if (ctaRef.current) {
        observer.unobserve(ctaRef.current);
      }
    };
  }, []);

  return (
    <section className="py-20 bg-indigo-600" ref={ctaRef}>
      <div className="container mx-auto px-4">
        <div 
          className={`max-w-4xl mx-auto text-center transition-all duration-700 ${
            isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
          }`}
        >
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Start Creating Your Perfect Photo Collages Today
          </h2>
          
          <p className="text-xl text-indigo-200 mb-10 max-w-2xl mx-auto">
            Join thousands of users who have transformed their memories into beautiful 
            collages. It's free to get started!
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <button className="w-full sm:w-auto bg-white hover:bg-gray-100 text-indigo-700 px-8 py-3 rounded-full text-lg font-medium transition-colors duration-200 flex items-center justify-center">
              Create Your First Collage <ArrowRight className="ml-2 h-5 w-5" />
            </button>
            <button className="w-full sm:w-auto bg-transparent hover:bg-indigo-700 text-white border border-white px-8 py-3 rounded-full text-lg font-medium transition-colors duration-200">
              View Templates
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CallToAction;