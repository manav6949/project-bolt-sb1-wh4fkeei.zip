import React from 'react';
import { ImageIcon, Github, Twitter, Instagram } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-1">
            <div className="flex items-center">
              <ImageIcon className="h-8 w-8 text-indigo-400" />
              <span className="ml-2 text-xl font-medium tracking-tight">FrameFlow</span>
            </div>
            <p className="mt-4 text-gray-400 text-sm">
              Create beautiful photo collages with our intuitive, easy-to-use tools. 
              Transform your memories into stunning layouts.
            </p>
            <div className="mt-6 flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Github className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-medium mb-4">Product</h3>
            <ul className="space-y-2">
              <FooterLink label="Features" />
              <FooterLink label="Templates" />
              <FooterLink label="Pricing" />
              <FooterLink label="Updates" />
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-medium mb-4">Resources</h3>
            <ul className="space-y-2">
              <FooterLink label="Gallery" />
              <FooterLink label="Tutorials" />
              <FooterLink label="Blog" />
              <FooterLink label="Help Center" />
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-medium mb-4">Company</h3>
            <ul className="space-y-2">
              <FooterLink label="About" />
              <FooterLink label="Contact" />
              <FooterLink label="Privacy Policy" />
              <FooterLink label="Terms of Service" />
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-500 text-sm">
            © {new Date().getFullYear()} FrameFlow. All rights reserved.
          </p>
          <div className="mt-4 md:mt-0">
            <select className="bg-gray-800 text-gray-400 text-sm py-1 px-3 rounded border border-gray-700 focus:outline-none focus:ring-1 focus:ring-indigo-500">
              <option>English (US)</option>
              <option>Français</option>
              <option>Español</option>
              <option>Deutsch</option>
            </select>
          </div>
        </div>
      </div>
    </footer>
  );
};

const FooterLink: React.FC<{ label: string }> = ({ label }) => (
  <li>
    <a href="#" className="text-gray-400 hover:text-white transition-colors text-sm">
      {label}
    </a>
  </li>
);

export default Footer;