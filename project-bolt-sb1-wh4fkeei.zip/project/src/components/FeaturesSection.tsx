import React, { useRef, useEffect, useState } from 'react';
import { Palette, Layout, Type, Image as ImageIcon, Download, Share2 } from 'lucide-react';

const features = [
  {
    icon: <Layout className="h-6 w-6" />,
    title: 'Multiple Layouts',
    description: 'Choose from various professionally designed layouts for your collages.',
  },
  {
    icon: <Palette className="h-6 w-6" />,
    title: 'Creative Filters',
    description: 'Enhance your photos with our collection of beautiful filters and effects.',
  },
  {
    icon: <Type className="h-6 w-6" />,
    title: 'Text Overlays',
    description: 'Add custom text with elegant typography to your collages.',
  },
  {
    icon: <ImageIcon className="h-6 w-6" />,
    title: 'Image Adjustments',
    description: 'Fine-tune brightness, contrast, and more for perfect photos.',
  },
  {
    icon: <Download className="h-6 w-6" />,
    title: 'Easy Download',
    description: 'Download your creations in high quality with a single click.',
  },
  {
    icon: <Share2 className="h-6 w-6" />,
    title: 'Share Instantly',
    description: 'Share your collages directly to social media or via email.',
  },
];

const FeaturesSection: React.FC = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      {
        threshold: 0.1,
      }
    );
    
    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }
    
    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  return (
    <section className="py-20 bg-white" ref={sectionRef}>
      <div className="container mx-auto px-4">
        <div 
          className={`text-center max-w-3xl mx-auto mb-16 transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900">Powerful Features for Perfect Collages</h2>
          <p className="mt-4 text-xl text-gray-600">
            Our intuitive tools make photo collage creation simple and delightful
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-12">
          {features.map((feature, index) => (
            <FeatureCard 
              key={index} 
              feature={feature} 
              index={index}
              isVisible={isVisible}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

interface FeatureCardProps {
  feature: {
    icon: React.ReactNode;
    title: string;
    description: string;
  };
  index: number;
  isVisible: boolean;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ feature, index, isVisible }) => {
  return (
    <div 
      className={`transition-all duration-700 delay-${index * 100} ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
      }`}
    >
      <div className="flex items-start">
        <div className="flex-shrink-0 bg-indigo-100 rounded-lg p-3 text-indigo-600">
          {feature.icon}
        </div>
        <div className="ml-4">
          <h3 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h3>
          <p className="text-gray-600 leading-relaxed">{feature.description}</p>
        </div>
      </div>
    </div>
  );
};

export default FeaturesSection;