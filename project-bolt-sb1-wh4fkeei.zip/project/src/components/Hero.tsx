import React from 'react';
import { ArrowRight } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="pt-32 pb-20 md:pt-40 md:pb-28">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h1 
            className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight"
            style={{ opacity: 0 }}
            ref={(el) => {
              if (el) {
                setTimeout(() => {
                  el.style.transition = 'opacity 0.8s ease-out, transform 0.8s ease-out';
                  el.style.opacity = '1';
                  el.style.transform = 'translateY(0)';
                }, 100);
              }
            }}
          >
            Create stunning photo collages with <span className="text-indigo-600">ease</span>
          </h1>
          
          <p 
            className="mt-6 text-xl md:text-2xl text-gray-600 leading-relaxed"
            style={{ opacity: 0 }}
            ref={(el) => {
              if (el) {
                setTimeout(() => {
                  el.style.transition = 'opacity 0.8s ease-out, transform 0.8s ease-out';
                  el.style.opacity = '1';
                  el.style.transform = 'translateY(0)';
                }, 300);
              }
            }}
          >
            Transform your memories into beautiful layouts with our intuitive collage maker.
            Add photos, customize layouts, and share your creations in minutes.
          </p>
          
          <div 
            className="mt-10 flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-4"
            style={{ opacity: 0 }}
            ref={(el) => {
              if (el) {
                setTimeout(() => {
                  el.style.transition = 'opacity 0.8s ease-out, transform 0.8s ease-out';
                  el.style.opacity = '1';
                  el.style.transform = 'translateY(0)';
                }, 500);
              }
            }}
          >
            <button className="w-full sm:w-auto bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-3 rounded-full text-lg font-medium transition-colors duration-200 flex items-center justify-center">
              Start Creating <ArrowRight className="ml-2 h-5 w-5" />
            </button>
            <button className="w-full sm:w-auto bg-white hover:bg-gray-100 text-gray-800 border border-gray-300 px-8 py-3 rounded-full text-lg font-medium transition-colors duration-200">
              View Gallery
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;