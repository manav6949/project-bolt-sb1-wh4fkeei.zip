import React, { useState } from 'react';
import { Upload, X, Image as ImageIcon } from 'lucide-react';

const DragDropUploader: React.FC = () => {
  const [isDragging, setIsDragging] = useState(false);
  
  const handleDragEnter = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };
  
  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };
  
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };
  
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    
    // In a real app, we'd process the files here
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      console.log("Files dropped:", e.dataTransfer.files);
      // Process files here
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div 
        className={`border-2 border-dashed rounded-xl p-8 transition-all duration-300 ${
          isDragging 
            ? 'border-indigo-500 bg-indigo-50' 
            : 'border-gray-300 hover:border-indigo-300 hover:bg-gray-50'
        }`}
        onDragEnter={handleDragEnter}
        onDragLeave={handleDragLeave}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
      >
        <div className="text-center">
          <div className="mx-auto w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mb-4">
            <Upload className="h-8 w-8 text-indigo-600" />
          </div>
          
          <h3 className="text-xl font-medium text-gray-900 mb-2">
            Drag and drop your photos
          </h3>
          
          <p className="text-gray-500 mb-6">
            or click to browse from your device
          </p>
          
          <button className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-lg text-sm font-medium transition-colors duration-200">
            Select Photos
          </button>
          
          <p className="text-xs text-gray-400 mt-4">
            Supported formats: JPG, PNG, WEBP
          </p>
        </div>
      </div>
      
      {/* Preview section - would show selected images */}
      <div className="mt-8">
        <div className="flex items-center justify-between mb-4">
          <h4 className="text-lg font-medium text-gray-900">Selected Photos</h4>
          <button className="text-sm text-indigo-600 hover:text-indigo-700">Clear all</button>
        </div>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
          {[1, 2, 3].map((item) => (
            <div key={item} className="relative group">
              <div className="aspect-square bg-gray-100 rounded-lg overflow-hidden flex items-center justify-center border border-gray-200">
                <ImageIcon className="h-8 w-8 text-gray-400" />
              </div>
              
              <button className="absolute top-2 right-2 bg-white/80 rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <X className="h-4 w-4 text-gray-700" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DragDropUploader;