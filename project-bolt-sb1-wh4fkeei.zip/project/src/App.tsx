import React, { useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import FeaturesSection from './components/FeaturesSection';
import TemplatesSection from './components/TemplatesSection';
import GallerySection from './components/GallerySection';
import DragDropUploader from './components/DragDropUploader';
import CallToAction from './components/CallToAction';
import Footer from './components/Footer';

function App() {
  useEffect(() => {
    // Update the page title
    document.title = 'FrameFlow | Beautiful Photo Collages';
    
    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function (e) {
        e.preventDefault();
        
        const href = this.getAttribute('href');
        if (href) {
          document.querySelector(href)?.scrollIntoView({
            behavior: 'smooth'
          });
        }
      });
    });
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Main Content */}
      <main>
        <Hero />
        
        <FeaturesSection />
        
        <section className="py-20 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">Upload Your Photos</h2>
              <p className="mt-4 text-xl text-gray-600">
                Drag and drop your images to get started with your collage
              </p>
            </div>
            
            <DragDropUploader />
          </div>
        </section>
        
        <TemplatesSection />
        
        <GallerySection />
        
        <CallToAction />
      </main>
      
      <Footer />
    </div>
  );
}

export default App;