import React, { useState, useEffect } from 'react';
import { Menu, X, Image as ImageIcon } from 'lucide-react';

const Header: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-white/90 backdrop-blur-md shadow-sm' : 'bg-transparent'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16 md:h-20">
          <div className="flex items-center">
            <ImageIcon className="h-8 w-8 text-indigo-600" />
            <span className="ml-2 text-xl font-medium tracking-tight">FrameFlow</span>
          </div>
          
          <nav className="hidden md:flex space-x-8">
            <NavLink label="Home" active />
            <NavLink label="Gallery" />
            <NavLink label="Templates" />
            <NavLink label="About" />
          </nav>
          
          <div className="hidden md:flex">
            <button className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 rounded-full text-sm font-medium transition-colors duration-200">
              Create Collage
            </button>
          </div>
          
          <button 
            className="md:hidden text-gray-800"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? (
              <X className="h-6 w-6" />
            ) : (
              <Menu className="h-6 w-6" />
            )}
          </button>
        </div>
      </div>
      
      {/* Mobile menu */}
      <div 
        className={`md:hidden absolute top-16 left-0 right-0 bg-white shadow-lg transition-all duration-300 ease-in-out transform ${
          mobileMenuOpen ? 'translate-y-0 opacity-100' : '-translate-y-2 opacity-0 pointer-events-none'
        }`}
      >
        <div className="px-4 py-4 space-y-4">
          <MobileNavLink label="Home" active />
          <MobileNavLink label="Gallery" />
          <MobileNavLink label="Templates" />
          <MobileNavLink label="About" />
          <button className="w-full bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 rounded-full text-sm font-medium transition-colors duration-200">
            Create Collage
          </button>
        </div>
      </div>
    </header>
  );
};

const NavLink: React.FC<{ label: string; active?: boolean }> = ({ label, active }) => (
  <a
    href="#"
    className={`text-sm font-medium transition-colors duration-200 ${
      active ? 'text-indigo-600' : 'text-gray-800 hover:text-indigo-600'
    }`}
  >
    {label}
  </a>
);

const MobileNavLink: React.FC<{ label: string; active?: boolean }> = ({ label, active }) => (
  <a
    href="#"
    className={`block py-2 text-base font-medium transition-colors duration-200 ${
      active ? 'text-indigo-600' : 'text-gray-800 hover:text-indigo-600'
    }`}
  >
    {label}
  </a>
);

export default Header;