import { Photo, CollageLayout, CollageItem } from '../types';

export const samplePhotos: Photo[] = [
  {
    id: '1',
    url: 'https://images.pexels.com/photos/1166209/pexels-photo-1166209.jpeg',
    alt: 'Mountain landscape with lake',
  },
  {
    id: '2',
    url: 'https://images.pexels.com/photos/2662116/pexels-photo-2662116.jpeg',
    alt: 'Desert sunset',
  },
  {
    id: '3',
    url: 'https://images.pexels.com/photos/1366630/pexels-photo-1366630.jpeg',
    alt: 'Tropical beach',
  },
  {
    id: '4',
    url: 'https://images.pexels.com/photos/1723637/pexels-photo-1723637.jpeg',
    alt: 'Forest path',
  },
  {
    id: '5',
    url: 'https://images.pexels.com/photos/1619317/pexels-photo-1619317.jpeg',
    alt: 'City skyline',
  },
  {
    id: '6',
    url: 'https://images.pexels.com/photos/1279813/pexels-photo-1279813.jpeg',
    alt: 'Architectural detail',
  },
];

export const collageLayouts: CollageLayout[] = [
  {
    id: 'grid-2',
    name: 'Grid (2)',
    imageCount: 2,
    template: 'grid',
  },
  {
    id: 'split-2',
    name: 'Split (2)',
    imageCount: 2,
    template: 'split',
  },
  {
    id: 'grid-3',
    name: 'Grid (3)',
    imageCount: 3,
    template: 'grid',
  },
  {
    id: 'grid-4',
    name: 'Grid (4)',
    imageCount: 4,
    template: 'grid',
  },
  {
    id: 'feature-3',
    name: 'Feature (3)',
    imageCount: 3,
    template: 'feature',
  },
];

export const sampleCollages: CollageItem[] = [
  {
    id: 'collage-1',
    photos: samplePhotos.slice(0, 2),
    layout: 'split-2',
    title: 'Nature Scenes',
    created: new Date('2023-05-15'),
  },
  {
    id: 'collage-2',
    photos: samplePhotos.slice(2, 6),
    layout: 'grid-4',
    title: 'Travel Memories',
    created: new Date('2023-06-22'),
  },
];