import React, { useState, useRef, useEffect } from 'react';
import { collageLayouts } from '../data/sampleData';
import { samplePhotos } from '../data/sampleData';
import { CollageLayout, Photo } from '../types';

const TemplatesSection: React.FC = () => {
  const [selectedLayout, setSelectedLayout] = useState<CollageLayout | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      {
        threshold: 0.1,
      }
    );
    
    if (containerRef.current) {
      observer.observe(containerRef.current);
    }
    
    return () => {
      if (containerRef.current) {
        observer.unobserve(containerRef.current);
      }
    };
  }, []);

  return (
    <section className="py-20 bg-gray-50" ref={containerRef}>
      <div className="container mx-auto px-4">
        <div 
          className={`text-center max-w-3xl mx-auto mb-16 transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900">Beautiful Collage Templates</h2>
          <p className="mt-4 text-xl text-gray-600">
            Choose from our professionally designed templates for your photos
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {collageLayouts.map((layout, index) => (
            <div 
              key={layout.id}
              className={`transition-all duration-700 delay-${index * 100} ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
            >
              <TemplateCard 
                layout={layout}
                isSelected={selectedLayout?.id === layout.id}
                onSelect={() => setSelectedLayout(layout)}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

interface TemplateCardProps {
  layout: CollageLayout;
  isSelected: boolean;
  onSelect: () => void;
}

const TemplateCard: React.FC<TemplateCardProps> = ({ layout, isSelected, onSelect }) => {
  // Select appropriate photos based on the template image count
  const templatePhotos = samplePhotos.slice(0, layout.imageCount);
  
  return (
    <div 
      className={`bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 cursor-pointer transform hover:-translate-y-1 ${
        isSelected ? 'ring-2 ring-indigo-500' : ''
      }`}
      onClick={onSelect}
    >
      <div className={getLayoutClass(layout.id, layout.template)}>
        {templatePhotos.map((photo, index) => (
          <TemplatePhoto 
            key={photo.id} 
            photo={photo} 
            layout={layout} 
            index={index} 
            total={templatePhotos.length} 
          />
        ))}
      </div>
      
      <div className="p-4">
        <h3 className="text-lg font-medium text-gray-900">{layout.name}</h3>
        <p className="text-sm text-gray-500">{layout.imageCount} photos</p>
      </div>
    </div>
  );
};

interface TemplatePhotoProps {
  photo: Photo;
  layout: CollageLayout;
  index: number;
  total: number;
}

const TemplatePhoto: React.FC<TemplatePhotoProps> = ({ photo, layout, index, total }) => {
  return (
    <div className={getPhotoClass(layout.id, layout.template, index, total)}>
      <img 
        src={photo.url} 
        alt={photo.alt}
        className="w-full h-full object-cover"
      />
    </div>
  );
};

// Helper functions for layout classes
const getLayoutClass = (layoutId: string, template: string): string => {
  switch (layoutId) {
    case 'grid-2':
      return 'grid grid-cols-2 aspect-video';
    case 'split-2':
      return 'grid grid-cols-2 aspect-video';
    case 'grid-3':
      return 'grid grid-cols-3 aspect-video';
    case 'grid-4':
      return 'grid grid-cols-2 grid-rows-2 aspect-square';
    case 'feature-3':
      return 'grid grid-cols-2 grid-rows-2 aspect-video';
    default:
      return 'grid grid-cols-1 aspect-video';
  }
};

const getPhotoClass = (layoutId: string, template: string, index: number, total: number): string => {
  switch (layoutId) {
    case 'feature-3':
      return index === 0 ? 'row-span-2' : '';
    default:
      return '';
  }
};

export default TemplatesSection;