export interface Photo {
  id: string;
  url: string;
  alt: string;
}

export interface CollageLayout {
  id: string;
  name: string;
  imageCount: number;
  template: string;
}

export type Filter = 'none' | 'grayscale' | 'sepia' | 'blur' | 'brightness' | 'contrast';

export interface CollageItem {
  id: string;
  photos: Photo[];
  layout: string;
  title: string;
  created: Date;
}