import React, { useRef, useEffect, useState } from 'react';
import CollageGrid from './CollageGrid';
import { sampleCollages } from '../data/sampleData';

const GallerySection: React.FC = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      {
        threshold: 0.1,
      }
    );
    
    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }
    
    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  return (
    <section className="py-20" ref={sectionRef}>
      <div className="container mx-auto px-4">
        <div 
          className={`text-center max-w-3xl mx-auto mb-16 transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900">Featured Collages</h2>
          <p className="mt-4 text-xl text-gray-600">
            Get inspired by what others have created with FrameFlow
          </p>
        </div>
        
        <div 
          className={`transition-all duration-700 delay-200 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <CollageGrid collages={sampleCollages} />
        </div>
        
        <div className="mt-12 text-center">
          <button className="bg-white hover:bg-gray-50 text-indigo-600 border border-indigo-200 px-8 py-3 rounded-lg text-lg font-medium transition-colors duration-200">
            View All Collages
          </button>
        </div>
      </div>
    </section>
  );
};

export default GallerySection;